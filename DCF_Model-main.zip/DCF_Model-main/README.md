# DCF_Model
This shows how to build DCF model using python 
